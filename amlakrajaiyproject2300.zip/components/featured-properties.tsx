import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Bed, Bath, Car, Square } from "lucide-react"
import Link from "next/link"

const featuredProperties = [
  {
    id: "1",
    title: "آپارتمان لوکس در کوثر",
    price: "2,500,000,000",
    type: "فروش",
    area: "120",
    bedrooms: 3,
    bathrooms: 2,
    parking: 1,
    location: "کوثر، بلوک 7",
    image: "/placeholder.svg?height=300&width=400&text=آپارتمان+لوکس",
    featured: true,
  },
  {
    id: "2",
    title: "ویلا دوبلکس در شهرک صنعتی",
    price: "4,200,000,000",
    type: "فروش",
    area: "250",
    bedrooms: 4,
    bathrooms: 3,
    parking: 2,
    location: "شهرک صنعتی",
    image: "/placeholder.svg?height=300&width=400&text=ویلا+دوبلکس",
    featured: true,
  },
  {
    id: "3",
    title: "آپارتمان اجاره‌ای مبله",
    price: "15,000,000",
    type: "اجاره",
    area: "85",
    bedrooms: 2,
    bathrooms: 1,
    parking: 1,
    location: "مرکز شهر",
    image: "/placeholder.svg?height=300&width=400&text=آپارتمان+مبله",
    featured: false,
  },
]

export function FeaturedProperties() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">املاک ویژه</h2>
            <p className="text-lg text-slate-600 text-pretty">بهترین املاک منتخب با قیمت‌های مناسب</p>
          </div>

          {/* Properties grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredProperties.map((property) => (
              <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={property.image || "/placeholder.svg"}
                    alt={property.title}
                    className="w-full h-48 object-cover"
                  />
                  {property.featured && <Badge className="absolute top-3 right-3 bg-blue-600">ویژه</Badge>}
                  <Badge
                    className={`absolute top-3 left-3 ${property.type === "فروش" ? "bg-green-600" : "bg-orange-600"}`}
                  >
                    {property.type}
                  </Badge>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg text-slate-900 mb-2">{property.title}</h3>
                  <div className="flex items-center text-slate-600 mb-3">
                    <MapPin className="h-4 w-4 ml-1" />
                    <span className="text-sm">{property.location}</span>
                  </div>

                  {/* Property details */}
                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm text-slate-600">
                    <div className="flex items-center">
                      <Square className="h-4 w-4 ml-1" />
                      <span>{property.area} متر</span>
                    </div>
                    <div className="flex items-center">
                      <Bed className="h-4 w-4 ml-1" />
                      <span>{property.bedrooms} خواب</span>
                    </div>
                    <div className="flex items-center">
                      <Bath className="h-4 w-4 ml-1" />
                      <span>{property.bathrooms} سرویس</span>
                    </div>
                    <div className="flex items-center">
                      <Car className="h-4 w-4 ml-1" />
                      <span>{property.parking} پارکینگ</span>
                    </div>
                  </div>

                  {/* Price and CTA */}
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-2xl font-bold text-blue-600">{property.price}</span>
                      <span className="text-sm text-slate-600 mr-1">
                        {property.type === "اجاره" ? "تومان/ماه" : "تومان"}
                      </span>
                    </div>
                    <Button size="sm" variant="outline">
                      مشاهده جزئیات
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* View all button */}
          <div className="text-center">
            <Link href="/properties">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                مشاهده همه املاک
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
