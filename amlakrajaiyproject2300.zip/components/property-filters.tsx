"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function PropertyFilters() {
  const [filters, setFilters] = useState({
    propertyType: "",
    transactionType: "",
    priceRange: [0, 10000000000],
    areaRange: [0, 500],
    bedrooms: "",
    bathrooms: "",
    features: [] as string[],
    neighborhood: "",
  })

  const features = [
    "آسانسور",
    "پارکینگ",
    "انباری",
    "بالکن",
    "تراس",
    "حیاط",
    "استخر",
    "سونا",
    "جکوزی",
    "باربیکیو",
    "کابینت MDF",
    "پکیج",
    "کولر",
    "شوفاژ",
  ]

  const neighborhoods = ["کوثر", "مرکز شهر", "شهرک صنعتی", "حومه شهر", "بلوار امام", "خیابان ولیعصر", "میدان شهدا"]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>فیلترهای جستجو</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Property type */}
          <div>
            <Label className="text-sm font-medium">نوع ملک</Label>
            <Select
              value={filters.propertyType}
              onValueChange={(value) => setFilters({ ...filters, propertyType: value })}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="انتخاب نوع ملک" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="apartment">آپارتمان</SelectItem>
                <SelectItem value="house">خانه</SelectItem>
                <SelectItem value="villa">ویلا</SelectItem>
                <SelectItem value="commercial">تجاری</SelectItem>
                <SelectItem value="land">زمین</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Transaction type */}
          <div>
            <Label className="text-sm font-medium">نوع معامله</Label>
            <Select
              value={filters.transactionType}
              onValueChange={(value) => setFilters({ ...filters, transactionType: value })}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="خرید یا اجاره" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sale">خرید</SelectItem>
                <SelectItem value="rent">اجاره</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Price range */}
          <div>
            <Label className="text-sm font-medium">محدوده قیمت (تومان)</Label>
            <div className="mt-4 px-2">
              <Slider
                value={filters.priceRange}
                onValueChange={(value) => setFilters({ ...filters, priceRange: value })}
                max={10000000000}
                min={0}
                step={100000000}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-slate-500 mt-2">
                <span>{filters.priceRange[0].toLocaleString()}</span>
                <span>{filters.priceRange[1].toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Area range */}
          <div>
            <Label className="text-sm font-medium">محدوده متراژ</Label>
            <div className="mt-4 px-2">
              <Slider
                value={filters.areaRange}
                onValueChange={(value) => setFilters({ ...filters, areaRange: value })}
                max={500}
                min={0}
                step={10}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-slate-500 mt-2">
                <span>{filters.areaRange[0]} متر</span>
                <span>{filters.areaRange[1]} متر</span>
              </div>
            </div>
          </div>

          {/* Bedrooms */}
          <div>
            <Label className="text-sm font-medium">تعداد خواب</Label>
            <Select value={filters.bedrooms} onValueChange={(value) => setFilters({ ...filters, bedrooms: value })}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="تعداد خواب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 خواب</SelectItem>
                <SelectItem value="2">2 خواب</SelectItem>
                <SelectItem value="3">3 خواب</SelectItem>
                <SelectItem value="4">4+ خواب</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Neighborhood */}
          <div>
            <Label className="text-sm font-medium">محله</Label>
            <Select
              value={filters.neighborhood}
              onValueChange={(value) => setFilters({ ...filters, neighborhood: value })}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="انتخاب محله" />
              </SelectTrigger>
              <SelectContent>
                {neighborhoods.map((neighborhood) => (
                  <SelectItem key={neighborhood} value={neighborhood}>
                    {neighborhood}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Features */}
          <div>
            <Label className="text-sm font-medium mb-3 block">امکانات</Label>
            <div className="grid grid-cols-2 gap-3 max-h-48 overflow-y-auto">
              {features.map((feature) => (
                <div key={feature} className="flex items-center space-x-2">
                  <Checkbox
                    id={feature}
                    checked={filters.features.includes(feature)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setFilters({ ...filters, features: [...filters.features, feature] })
                      } else {
                        setFilters({ ...filters, features: filters.features.filter((f) => f !== feature) })
                      }
                    }}
                  />
                  <Label htmlFor={feature} className="text-sm">
                    {feature}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Apply filters button */}
          <Button className="w-full bg-blue-600 hover:bg-blue-700">اعمال فیلترها</Button>
        </CardContent>
      </Card>
    </div>
  )
}
