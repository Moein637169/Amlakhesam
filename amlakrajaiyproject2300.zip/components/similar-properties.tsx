"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Bed, Bath, Car, Square } from "lucide-react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import type { Property } from "@/lib/types"

interface SimilarPropertiesProps {
  propertyId: string
}

export function SimilarProperties({ propertyId }: SimilarPropertiesProps) {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSimilarProperties()
  }, [propertyId])

  const fetchSimilarProperties = async () => {
    try {
      const supabase = createClient()

      // First get the current property to find similar ones
      const { data: currentProperty } = await supabase.from("properties").select("*").eq("id", propertyId).single()

      if (!currentProperty) return

      // Find similar properties based on type, transaction type, and price range
      const { data, error } = await supabase
        .from("properties")
        .select("*")
        .eq("property_type", currentProperty.property_type)
        .eq("transaction_type", currentProperty.transaction_type)
        .eq("status", "available")
        .neq("id", propertyId)
        .gte("price", currentProperty.price * 0.7) // 30% lower
        .lte("price", currentProperty.price * 1.3) // 30% higher
        .limit(6)

      if (error) throw error
      setProperties(data || [])
    } catch (error) {
      console.error("Error fetching similar properties:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number, transactionType: string) => {
    return `${price.toLocaleString()} ${transactionType === "rent" ? "تومان/ماه" : "تومان"}`
  }

  if (loading) {
    return (
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-slate-900 mb-8">املاک مشابه</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-48 bg-slate-200 rounded-t-lg"></div>
                  <CardContent className="p-6">
                    <div className="h-4 bg-slate-200 rounded mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-2/3 mb-4"></div>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="h-3 bg-slate-200 rounded"></div>
                      <div className="h-3 bg-slate-200 rounded"></div>
                    </div>
                    <div className="h-8 bg-slate-200 rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>
    )
  }

  if (properties.length === 0) {
    return null
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-slate-900">املاک مشابه</h2>
            <Link href="/properties">
              <Button variant="outline">مشاهده همه املاک</Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((property) => (
              <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={property.images?.[0] || "/placeholder.svg?height=300&width=400"}
                    alt={property.title}
                    className="w-full h-48 object-cover"
                  />
                  {property.featured && <Badge className="absolute top-3 right-3 bg-blue-600">ویژه</Badge>}
                  <Badge
                    className={`absolute top-3 left-3 ${
                      property.transaction_type === "sale" ? "bg-green-600" : "bg-orange-600"
                    }`}
                  >
                    {property.transaction_type === "sale" ? "فروش" : "اجاره"}
                  </Badge>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-1">{property.title}</h3>
                  <div className="flex items-center text-slate-600 mb-3">
                    <MapPin className="h-4 w-4 ml-1" />
                    <span className="text-sm line-clamp-1">{property.address}</span>
                  </div>

                  {/* Property details */}
                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm text-slate-600">
                    <div className="flex items-center">
                      <Square className="h-4 w-4 ml-1" />
                      <span>{property.area} متر</span>
                    </div>
                    {property.bedrooms && (
                      <div className="flex items-center">
                        <Bed className="h-4 w-4 ml-1" />
                        <span>{property.bedrooms} خواب</span>
                      </div>
                    )}
                    {property.bathrooms && (
                      <div className="flex items-center">
                        <Bath className="h-4 w-4 ml-1" />
                        <span>{property.bathrooms} سرویس</span>
                      </div>
                    )}
                    {property.parking_spaces && (
                      <div className="flex items-center">
                        <Car className="h-4 w-4 ml-1" />
                        <span>{property.parking_spaces} پارکینگ</span>
                      </div>
                    )}
                  </div>

                  {/* Price and CTA */}
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-xl font-bold text-blue-600">
                        {formatPrice(property.price, property.transaction_type)}
                      </span>
                    </div>
                    <Link href={`/properties/${property.id}`}>
                      <Button size="sm" variant="outline">
                        مشاهده جزئیات
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
