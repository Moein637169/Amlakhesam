"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Maximize2, Play } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Property } from "@/lib/types"

interface PropertyGalleryProps {
  propertyId: string
}

export function PropertyGallery({ propertyId }: PropertyGalleryProps) {
  const [property, setProperty] = useState<Property | null>(null)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)

  useEffect(() => {
    fetchProperty()
  }, [propertyId])

  const fetchProperty = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase.from("properties").select("*").eq("id", propertyId).single()

      if (error) throw error
      setProperty(data)
    } catch (error) {
      console.error("Error fetching property:", error)
    }
  }

  if (!property || !property.images || property.images.length === 0) {
    return (
      <section className="relative h-96 bg-slate-200 flex items-center justify-center">
        <p className="text-slate-500">تصویری برای نمایش وجود ندارد</p>
      </section>
    )
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images!.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images!.length) % property.images!.length)
  }

  return (
    <>
      {/* Main gallery */}
      <section className="relative h-96 md:h-[500px] bg-black">
        <img
          src={property.images[currentImageIndex] || "/placeholder.svg?height=500&width=800"}
          alt={`${property.title} - تصویر ${currentImageIndex + 1}`}
          className="w-full h-full object-cover"
        />

        {/* Navigation arrows */}
        {property.images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </>
        )}

        {/* Gallery controls */}
        <div className="absolute bottom-4 left-4 flex gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setIsFullscreen(true)}
            className="bg-black/50 hover:bg-black/70 text-white border-0"
          >
            <Maximize2 className="h-4 w-4 ml-1" />
            نمایش کامل
          </Button>
          {property.video_url && (
            <Button variant="secondary" size="sm" className="bg-black/50 hover:bg-black/70 text-white border-0">
              <Play className="h-4 w-4 ml-1" />
              ویدیو
            </Button>
          )}
        </div>

        {/* Image counter */}
        <div className="absolute bottom-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
          {currentImageIndex + 1} / {property.images.length}
        </div>
      </section>

      {/* Thumbnail strip */}
      {property.images.length > 1 && (
        <section className="py-4 bg-white border-b">
          <div className="container mx-auto px-4">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {property.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`flex-shrink-0 w-20 h-16 rounded-lg overflow-hidden border-2 transition-colors ${
                    index === currentImageIndex ? "border-blue-600" : "border-transparent"
                  }`}
                >
                  <img
                    src={image || "/placeholder.svg?height=64&width=80"}
                    alt={`تصویر ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Fullscreen modal */}
      {isFullscreen && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          <button
            onClick={() => setIsFullscreen(false)}
            className="absolute top-4 right-4 text-white hover:text-gray-300 text-2xl z-10"
          >
            ✕
          </button>
          <img
            src={property.images[currentImageIndex] || "/placeholder.svg"}
            alt={`${property.title} - تصویر ${currentImageIndex + 1}`}
            className="max-w-full max-h-full object-contain"
          />
          {property.images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full"
              >
                <ChevronLeft className="h-8 w-8" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full"
              >
                <ChevronRight className="h-8 w-8" />
              </button>
            </>
          )}
        </div>
      )}
    </>
  )
}
