"use client"

import { useState } from "react"
import { AdminSidebar } from "./admin-sidebar"
import { AdminHeader } from "./admin-header"
import { PropertiesManagement } from "./properties-management"
import { InquiriesManagement } from "./inquiries-management"
import { BlogManagement } from "./blog-management"
import { DashboardOverview } from "./dashboard-overview"

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const renderContent = () => {
    switch (activeTab) {
      case "overview":
        return <DashboardOverview />
      case "properties":
        return <PropertiesManagement />
      case "inquiries":
        return <InquiriesManagement />
      case "blog":
        return <BlogManagement />
      default:
        return <DashboardOverview />
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminHeader />
      <div className="flex">
        <AdminSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 p-8">{renderContent()}</main>
      </div>
    </div>
  )
}
