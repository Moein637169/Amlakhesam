"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Eye, MessageSquare, Phone, Mail } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Inquiry } from "@/lib/types"

export function InquiriesManagement() {
  const [inquiries, setInquiries] = useState<Inquiry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchInquiries()
  }, [])

  const fetchInquiries = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase.from("inquiries").select("*").order("created_at", { ascending: false })

      if (error) throw error
      setInquiries(data || [])
    } catch (error) {
      console.error("Error fetching inquiries:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      new: { label: "جدید", className: "bg-red-600" },
      contacted: { label: "تماس گرفته شده", className: "bg-orange-600" },
      closed: { label: "بسته شده", className: "bg-green-600" },
    }
    const statusInfo = statusMap[status as keyof typeof statusMap] || { label: status, className: "bg-gray-600" }
    return <Badge className={statusInfo.className}>{statusInfo.label}</Badge>
  }

  const getInquiryTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      viewing: "درخواست بازدید",
      info: "درخواست اطلاعات",
      offer: "پیشنهاد قیمت",
      general: "عمومی",
    }
    return types[type] || type
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-slate-900">مدیریت درخواست‌ها</h1>
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="h-4 bg-slate-200 rounded mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-900">مدیریت درخواست‌ها</h1>
        <div className="flex gap-2">
          <Button variant="outline">فیلتر</Button>
          <Button variant="outline">صادرات</Button>
        </div>
      </div>

      {/* Inquiries list */}
      <div className="space-y-4">
        {inquiries.map((inquiry) => (
          <Card key={inquiry.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="font-bold text-lg text-slate-900">{inquiry.name}</h3>
                    {getStatusBadge(inquiry.status)}
                    <Badge variant="secondary">{getInquiryTypeLabel(inquiry.inquiry_type)}</Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center gap-2 text-slate-600">
                      <Phone className="h-4 w-4" />
                      <span>{inquiry.phone}</span>
                    </div>
                    {inquiry.email && (
                      <div className="flex items-center gap-2 text-slate-600">
                        <Mail className="h-4 w-4" />
                        <span>{inquiry.email}</span>
                      </div>
                    )}
                  </div>

                  {inquiry.message && (
                    <div className="bg-slate-50 p-4 rounded-lg mb-4">
                      <p className="text-slate-700">{inquiry.message}</p>
                    </div>
                  )}

                  <div className="text-sm text-slate-500">
                    تاریخ: {new Date(inquiry.created_at).toLocaleDateString("fa-IR")}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button size="sm" className="bg-green-600 hover:bg-green-700">
                    <Phone className="h-4 w-4 ml-1" />
                    تماس
                  </Button>
                  <Button size="sm" variant="outline">
                    <MessageSquare className="h-4 w-4 ml-1" />
                    پیام
                  </Button>
                  <Button size="sm" variant="outline">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {inquiries.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-slate-500">هیچ درخواستی یافت نشد</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
