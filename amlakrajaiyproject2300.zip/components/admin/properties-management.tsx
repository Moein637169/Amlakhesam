"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, Eye } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Property } from "@/lib/types"

export function PropertiesManagement() {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    fetchProperties()
  }, [])

  const fetchProperties = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase.from("properties").select("*").order("created_at", { ascending: false })

      if (error) throw error
      setProperties(data || [])
    } catch (error) {
      console.error("Error fetching properties:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredProperties = properties.filter(
    (property) =>
      property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.address.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusBadge = (status: string) => {
    const statusMap = {
      available: { label: "موجود", className: "bg-green-600" },
      sold: { label: "فروخته شده", className: "bg-red-600" },
      rented: { label: "اجاره داده شده", className: "bg-blue-600" },
      pending: { label: "در انتظار", className: "bg-orange-600" },
    }
    const statusInfo = statusMap[status as keyof typeof statusMap] || { label: status, className: "bg-gray-600" }
    return <Badge className={statusInfo.className}>{statusInfo.label}</Badge>
  }

  const getPropertyTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      apartment: "آپارتمان",
      house: "خانه",
      villa: "ویلا",
      commercial: "تجاری",
      land: "زمین",
    }
    return types[type] || type
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-slate-900">مدیریت املاک</h1>
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="h-4 bg-slate-200 rounded mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-900">مدیریت املاک</h1>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 ml-2" />
          افزودن ملک جدید
        </Button>
      </div>

      {/* Search and filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  placeholder="جستجو در املاک..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <Button variant="outline">فیلتر</Button>
          </div>
        </CardContent>
      </Card>

      {/* Properties list */}
      <div className="space-y-4">
        {filteredProperties.map((property) => (
          <Card key={property.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <img
                    src={property.images?.[0] || "/placeholder.svg?height=80&width=80"}
                    alt={property.title}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                  <div>
                    <h3 className="font-bold text-lg text-slate-900">{property.title}</h3>
                    <p className="text-slate-600 text-sm">{property.address}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary">{getPropertyTypeLabel(property.property_type)}</Badge>
                      <Badge className={property.transaction_type === "sale" ? "bg-green-600" : "bg-orange-600"}>
                        {property.transaction_type === "sale" ? "فروش" : "اجاره"}
                      </Badge>
                      {getStatusBadge(property.status)}
                      {property.featured && <Badge className="bg-blue-600">ویژه</Badge>}
                    </div>
                  </div>
                </div>
                <div className="text-left">
                  <div className="text-xl font-bold text-blue-600 mb-2">{property.price.toLocaleString()} تومان</div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProperties.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-slate-500">هیچ ملکی یافت نشد</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
