"use client"

import { Button } from "@/components/ui/button"
import { Building, MessageSquare, FileText, BarChart3 } from "lucide-react"

interface AdminSidebarProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function AdminSidebar({ activeTab, onTabChange }: AdminSidebarProps) {
  const menuItems = [
    { id: "overview", label: "داشبورد", icon: BarChart3 },
    { id: "properties", label: "مدیریت املاک", icon: Building },
    { id: "inquiries", label: "درخواست‌ها", icon: MessageSquare },
    { id: "blog", label: "وبلاگ", icon: FileText },
  ]

  return (
    <aside className="w-64 bg-white border-l border-slate-200 min-h-screen">
      <nav className="p-4">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant={activeTab === item.id ? "default" : "ghost"}
              className={`w-full justify-start ${
                activeTab === item.id ? "bg-blue-600 text-white" : "text-slate-700 hover:bg-slate-100"
              }`}
              onClick={() => onTabChange(item.id)}
            >
              <item.icon className="h-4 w-4 ml-2" />
              {item.label}
            </Button>
          ))}
        </div>
      </nav>
    </aside>
  )
}
