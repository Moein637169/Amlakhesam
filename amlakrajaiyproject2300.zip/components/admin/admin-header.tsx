"use client"

import { Button } from "@/components/ui/button"
import { Bell, User, LogOut } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

export function AdminHeader() {
  const router = useRouter()

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/admin/login")
  }

  return (
    <header className="bg-white border-b border-slate-200 px-8 py-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 text-white p-2 rounded-lg">
            <span className="font-bold text-xl">ر</span>
          </div>
          <div>
            <h1 className="font-bold text-xl text-slate-900">پنل مدیریت املاک رجایی</h1>
            <p className="text-sm text-slate-600">سیستم مدیریت املاک</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm">
            <Bell className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <User className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4" />
            خروج
          </Button>
        </div>
      </div>
    </header>
  )
}
