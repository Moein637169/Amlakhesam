"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Search } from "lucide-react"

export function PropertySearch() {
  const [searchData, setSearchData] = useState({
    type: "",
    transaction: "",
    location: "",
    minPrice: "",
    maxPrice: "",
    bedrooms: "",
  })

  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">جستجوی پیشرفته املاک</h2>
            <p className="text-lg text-slate-600 text-pretty">با فیلترهای دقیق، ملک مورد نظر خود را پیدا کنید</p>
          </div>

          {/* Search form */}
          <Card className="shadow-lg">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                {/* Property type */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">نوع ملک</label>
                  <Select
                    value={searchData.type}
                    onValueChange={(value) => setSearchData({ ...searchData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب نوع ملک" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="apartment">آپارتمان</SelectItem>
                      <SelectItem value="house">خانه</SelectItem>
                      <SelectItem value="villa">ویلا</SelectItem>
                      <SelectItem value="commercial">تجاری</SelectItem>
                      <SelectItem value="land">زمین</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Transaction type */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">نوع معامله</label>
                  <Select
                    value={searchData.transaction}
                    onValueChange={(value) => setSearchData({ ...searchData, transaction: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="خرید یا اجاره" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sale">خرید</SelectItem>
                      <SelectItem value="rent">اجاره</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Location */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">منطقه</label>
                  <Select
                    value={searchData.location}
                    onValueChange={(value) => setSearchData({ ...searchData, location: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب منطقه" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kosar">کوثر</SelectItem>
                      <SelectItem value="center">مرکز شهر</SelectItem>
                      <SelectItem value="industrial">شهرک صنعتی</SelectItem>
                      <SelectItem value="suburbs">حومه شهر</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Min price */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">حداقل قیمت</label>
                  <Input
                    placeholder="مثال: 1000000000"
                    value={searchData.minPrice}
                    onChange={(e) => setSearchData({ ...searchData, minPrice: e.target.value })}
                  />
                </div>

                {/* Max price */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">حداکثر قیمت</label>
                  <Input
                    placeholder="مثال: 5000000000"
                    value={searchData.maxPrice}
                    onChange={(e) => setSearchData({ ...searchData, maxPrice: e.target.value })}
                  />
                </div>

                {/* Bedrooms */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">تعداد خواب</label>
                  <Select
                    value={searchData.bedrooms}
                    onValueChange={(value) => setSearchData({ ...searchData, bedrooms: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="تعداد خواب" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 خواب</SelectItem>
                      <SelectItem value="2">2 خواب</SelectItem>
                      <SelectItem value="3">3 خواب</SelectItem>
                      <SelectItem value="4">4+ خواب</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Search button */}
              <div className="flex justify-center">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-12">
                  <Search className="ml-2 h-5 w-5" />
                  جستجو در املاک
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick search options */}
          <div className="mt-8 text-center">
            <p className="text-slate-600 mb-4">جستجوهای پرطرفدار:</p>
            <div className="flex flex-wrap justify-center gap-3">
              <Button variant="outline" size="sm">
                آپارتمان کوثر
              </Button>
              <Button variant="outline" size="sm">
                ویلا حومه شهر
              </Button>
              <Button variant="outline" size="sm">
                مغازه مرکز شهر
              </Button>
              <Button variant="outline" size="sm">
                زمین مسکونی
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
