"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Bed, Bath, Car, Square, Heart } from "lucide-react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import type { Property } from "@/lib/types"

export function PropertyGrid() {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [favorites, setFavorites] = useState<string[]>([])

  useEffect(() => {
    fetchProperties()
  }, [])

  const fetchProperties = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from("properties")
        .select("*")
        .eq("status", "available")
        .order("created_at", { ascending: false })

      if (error) throw error
      setProperties(data || [])
    } catch (error) {
      console.error("Error fetching properties:", error)
    } finally {
      setLoading(false)
    }
  }

  const toggleFavorite = (propertyId: string) => {
    setFavorites((prev) => (prev.includes(propertyId) ? prev.filter((id) => id !== propertyId) : [...prev, propertyId]))
  }

  const formatPrice = (price: number, transactionType: string) => {
    return `${price.toLocaleString()} ${transactionType === "rent" ? "تومان/ماه" : "تومان"}`
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <div className="h-48 bg-slate-200 rounded-t-lg"></div>
            <CardContent className="p-6">
              <div className="h-4 bg-slate-200 rounded mb-2"></div>
              <div className="h-4 bg-slate-200 rounded w-2/3 mb-4"></div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="h-3 bg-slate-200 rounded"></div>
                <div className="h-3 bg-slate-200 rounded"></div>
              </div>
              <div className="h-8 bg-slate-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div>
      {/* Results header */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">{properties.length} ملک یافت شد</h2>
        <select className="border border-slate-300 rounded-lg px-3 py-2 text-sm">
          <option>مرتب‌سازی بر اساس</option>
          <option>جدیدترین</option>
          <option>قیمت: کم به زیاد</option>
          <option>قیمت: زیاد به کم</option>
          <option>متراژ: کم به زیاد</option>
          <option>متراژ: زیاد به کم</option>
        </select>
      </div>

      {/* Properties grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {properties.map((property) => (
          <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
            <div className="relative">
              <img
                src={property.images?.[0] || "/placeholder.svg?height=300&width=400"}
                alt={property.title}
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              {property.featured && <Badge className="absolute top-3 right-3 bg-blue-600">ویژه</Badge>}
              <Badge
                className={`absolute top-3 left-3 ${
                  property.transaction_type === "sale" ? "bg-green-600" : "bg-orange-600"
                }`}
              >
                {property.transaction_type === "sale" ? "فروش" : "اجاره"}
              </Badge>
              <button
                onClick={() => toggleFavorite(property.id)}
                className="absolute bottom-3 right-3 bg-white/80 hover:bg-white p-2 rounded-full transition-colors"
              >
                <Heart
                  className={`h-4 w-4 ${
                    favorites.includes(property.id) ? "fill-red-500 text-red-500" : "text-slate-600"
                  }`}
                />
              </button>
            </div>
            <CardContent className="p-6">
              <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-1">{property.title}</h3>
              <div className="flex items-center text-slate-600 mb-3">
                <MapPin className="h-4 w-4 ml-1" />
                <span className="text-sm line-clamp-1">{property.address}</span>
              </div>

              {/* Property details */}
              <div className="grid grid-cols-2 gap-4 mb-4 text-sm text-slate-600">
                <div className="flex items-center">
                  <Square className="h-4 w-4 ml-1" />
                  <span>{property.area} متر</span>
                </div>
                {property.bedrooms && (
                  <div className="flex items-center">
                    <Bed className="h-4 w-4 ml-1" />
                    <span>{property.bedrooms} خواب</span>
                  </div>
                )}
                {property.bathrooms && (
                  <div className="flex items-center">
                    <Bath className="h-4 w-4 ml-1" />
                    <span>{property.bathrooms} سرویس</span>
                  </div>
                )}
                {property.parking_spaces && (
                  <div className="flex items-center">
                    <Car className="h-4 w-4 ml-1" />
                    <span>{property.parking_spaces} پارکینگ</span>
                  </div>
                )}
              </div>

              {/* Price and CTA */}
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-xl font-bold text-blue-600">
                    {formatPrice(property.price, property.transaction_type)}
                  </span>
                </div>
                <Link href={`/properties/${property.id}`}>
                  <Button size="sm" variant="outline">
                    مشاهده جزئیات
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load more button */}
      {properties.length > 0 && (
        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            نمایش املاک بیشتر
          </Button>
        </div>
      )}
    </div>
  )
}
