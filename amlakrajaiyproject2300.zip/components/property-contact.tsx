"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Phone, Mail, MessageCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface PropertyContactProps {
  propertyId: string
}

export function PropertyContact({ propertyId }: PropertyContactProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
    inquiryType: "info",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const supabase = createClient()
      const { error } = await supabase.from("inquiries").insert({
        property_id: propertyId,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        message: formData.message,
        inquiry_type: formData.inquiryType,
      })

      if (error) throw error

      setSubmitted(true)
      setFormData({
        name: "",
        email: "",
        phone: "",
        message: "",
        inquiryType: "info",
      })
    } catch (error) {
      console.error("Error submitting inquiry:", error)
      alert("خطا در ارسال پیام. لطفاً دوباره تلاش کنید.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">پیام شما ارسال شد</h3>
                <p className="text-slate-600 mb-6">
                  پیام شما با موفقیت ارسال شد. کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت.
                </p>
                <Button onClick={() => setSubmitted(false)} variant="outline">
                  ارسال پیام جدید
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">درخواست اطلاعات بیشتر</h2>
            <p className="text-lg text-slate-600">
              برای کسب اطلاعات بیشتر درباره این ملک، فرم زیر را تکمیل کنید یا با ما تماس بگیرید
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact form */}
            <Card>
              <CardHeader>
                <CardTitle>فرم درخواست اطلاعات</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">نام و نام خانوادگی *</label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="نام خود را وارد کنید"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">شماره تماس *</label>
                    <Input
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="09xxxxxxxxx"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">ایمیل</label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="example@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">نوع درخواست</label>
                    <Select
                      value={formData.inquiryType}
                      onValueChange={(value) => setFormData({ ...formData, inquiryType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="info">درخواست اطلاعات</SelectItem>
                        <SelectItem value="viewing">درخواست بازدید</SelectItem>
                        <SelectItem value="offer">پیشنهاد قیمت</SelectItem>
                        <SelectItem value="general">سایر</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">پیام</label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="پیام خود را بنویسید..."
                      rows={4}
                    />
                  </div>

                  <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
                    {isSubmitting ? "در حال ارسال..." : "ارسال درخواست"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact info */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>تماس مستقیم</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center mb-6">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-blue-600 font-bold text-2xl">ر</span>
                    </div>
                    <h3 className="font-bold text-xl text-slate-900">مشاور املاک رجایی</h3>
                    <p className="text-slate-600">مشاور تخصصی املاک اردبیل</p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                      <Phone className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium text-slate-900">حسام رجایی</p>
                        <p className="text-slate-600">09141234567</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                      <Phone className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium text-slate-900">عباس رجایی</p>
                        <p className="text-slate-600">09149876543</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                      <Mail className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium text-slate-900">ایمیل</p>
                        <p className="text-slate-600">Amlakerajaei127@gmail.com</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mt-6">
                    <Button className="bg-green-600 hover:bg-green-700">
                      <Phone className="h-4 w-4 ml-1" />
                      تماس تلفنی
                    </Button>
                    <Button variant="outline">
                      <MessageCircle className="h-4 w-4 ml-1" />
                      پیام واتساپ
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>ساعات کاری</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-600">شنبه تا چهارشنبه:</span>
                      <span className="font-medium">8:00 - 20:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">پنج‌شنبه:</span>
                      <span className="font-medium">8:00 - 18:00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">جمعه:</span>
                      <span className="font-medium text-red-600">تعطیل</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
