import { Card, CardContent } from "@/components/ui/card"
import { Home, Search, FileText, Calculator, Users, Shield } from "lucide-react"

const services = [
  {
    icon: Search,
    title: "جستجوی تخصصی",
    description: "با فیلترهای پیشرفته، ملک مورد نظر خود را سریع پیدا کنید",
  },
  {
    icon: Home,
    title: "خرید و فروش",
    description: "خدمات کامل خرید و فروش انواع املاک با بهترین قیمت‌ها",
  },
  {
    icon: FileText,
    title: "مشاوره حقوقی",
    description: "مشاوره تخصصی در امور حقوقی و قراردادهای املاک",
  },
  {
    icon: Calculator,
    title: "ارزیابی ملک",
    description: "ارزیابی دقیق و کارشناسی املاک با قیمت روز بازار",
  },
  {
    icon: Users,
    title: "مشاوره رایگان",
    description: "مشاوره رایگان با کارشناسان مجرب در زمینه املاک",
  },
  {
    icon: Shield,
    title: "تضمین معامله",
    description: "انجام معاملات با کامل‌ترین تضمین‌ها و بیمه",
  },
]

export function Services() {
  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">خدمات ما</h2>
            <p className="text-lg text-slate-600 text-pretty">مجموعه کاملی از خدمات تخصصی املاک برای رفاه حال شما</p>
          </div>

          {/* Services grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                    <service.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-xl text-slate-900 mb-4">{service.title}</h3>
                  <p className="text-slate-600 text-pretty">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
