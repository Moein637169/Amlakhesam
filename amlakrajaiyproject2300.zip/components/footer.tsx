import Link from "next/link"
import { Phone, Mail, MapPin, Facebook, Instagram, Instagram as Telegram } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company info */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <span className="font-bold text-xl">ر</span>
              </div>
              <div>
                <h3 className="font-bold text-xl">مشاور املاک رجایی</h3>
                <p className="text-sm text-slate-400">خدمات تخصصی املاک</p>
              </div>
            </div>
            <p className="text-slate-400 text-sm mb-4">
              مشاور املاک رجایی با بیش از 10 سال تجربه، بهترین خدمات املاک را در اردبیل ارائه می‌دهد.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-slate-400 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white">
                <Telegram className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-bold text-lg mb-4">لینک‌های سریع</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link href="/" className="hover:text-white">
                  خانه
                </Link>
              </li>
              <li>
                <Link href="/properties" className="hover:text-white">
                  املاک
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white">
                  درباره ما
                </Link>
              </li>
              <li>
                <Link href="/blog" className="hover:text-white">
                  وبلاگ
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white">
                  تماس با ما
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-4">خدمات</h4>
            <ul className="space-y-2 text-slate-400">
              <li>خرید و فروش آپارتمان</li>
              <li>خرید و فروش ویلا</li>
              <li>اجاره املاک</li>
              <li>مشاوره املاک</li>
              <li>ارزیابی ملک</li>
            </ul>
          </div>

          {/* Contact info */}
          <div>
            <h4 className="font-bold text-lg mb-4">اطلاعات تماس</h4>
            <div className="space-y-3 text-slate-400">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span className="text-sm">09141234567</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span className="text-sm">Amlakerajaei127@gmail.com</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-1" />
                <span className="text-sm">اردبیل، کوثر، بلوک 7، واحد 127</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-slate-800 mt-8 pt-8 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-sm">© 1403 مشاور املاک رجایی. تمامی حقوق محفوظ است.</p>
            <div className="flex gap-6 text-sm text-slate-400">
              <Link href="/privacy" className="hover:text-white">
                حریم خصوصی
              </Link>
              <Link href="/terms" className="hover:text-white">
                شرایط استفاده
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
