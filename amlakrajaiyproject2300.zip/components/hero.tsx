import { Button } from "@/components/ui/button"
import { Search, MapPin, TrendingUp } from "lucide-react"

export function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900 text-white">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-black/20"></div>

      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="/modern-luxury-real-estate-building-in-ardabil-iran.jpg"
          alt="املاک لوکس اردبیل"
          className="w-full h-full object-cover opacity-30"
        />
      </div>

      <div className="relative container mx-auto px-4 py-24 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main heading */}
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
            بهترین املاک اردبیل را
            <span className="text-blue-400 block">با ما پیدا کنید</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-slate-300 mb-8 text-pretty">
            مشاور املاک رجایی با بیش از 10 سال تجربه، بهترین خدمات خرید، فروش و اجاره املاک را در اردبیل ارائه می‌دهد
          </p>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-blue-400 mb-2">500+</div>
              <div className="text-slate-300">املاک فروخته شده</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-blue-400 mb-2">10+</div>
              <div className="text-slate-300">سال تجربه</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-blue-400 mb-2">1000+</div>
              <div className="text-slate-300">مشتری راضی</div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
              <Search className="ml-2 h-5 w-5" />
              جستجوی املاک
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-slate-900 text-lg px-8 py-3 bg-transparent"
            >
              <MapPin className="ml-2 h-5 w-5" />
              مشاهده نقشه
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="mt-12 flex flex-wrap justify-center items-center gap-8 text-slate-400">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              <span>قیمت‌های روز بازار</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              <span>بهترین لوکیشن‌ها</span>
            </div>
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              <span>مشاوره تخصصی</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
