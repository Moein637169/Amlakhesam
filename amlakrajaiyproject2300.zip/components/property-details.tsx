"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, Bed, Bath, Car, Square, Calendar, Eye, Share2, Heart } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import type { Property } from "@/lib/types"

interface PropertyDetailsProps {
  propertyId: string
}

export function PropertyDetails({ propertyId }: PropertyDetailsProps) {
  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    fetchProperty()
  }, [propertyId])

  const fetchProperty = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase.from("properties").select("*").eq("id", propertyId).single()

      if (error) throw error
      setProperty(data)
    } catch (error) {
      console.error("Error fetching property:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number, transactionType: string) => {
    return `${price.toLocaleString()} ${transactionType === "rent" ? "تومان/ماه" : "تومان"}`
  }

  const getPropertyTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      apartment: "آپارتمان",
      house: "خانه",
      villa: "ویلا",
      commercial: "تجاری",
      land: "زمین",
    }
    return types[type] || type
  }

  if (loading) {
    return (
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse">
              <div className="h-8 bg-slate-200 rounded mb-4"></div>
              <div className="h-4 bg-slate-200 rounded w-2/3 mb-8"></div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <div className="h-64 bg-slate-200 rounded"></div>
                </div>
                <div className="h-96 bg-slate-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </section>
    )
  }

  if (!property) {
    return (
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">ملک یافت نشد</h1>
            <p className="text-slate-600">ملک مورد نظر شما یافت نشد یا حذف شده است.</p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Property header */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-6">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">{property.title}</h1>
                <div className="flex items-center text-slate-600 mb-4">
                  <MapPin className="h-5 w-5 ml-2" />
                  <span>{property.address}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{getPropertyTypeLabel(property.property_type)}</Badge>
                  <Badge className={property.transaction_type === "sale" ? "bg-green-600" : "bg-orange-600"}>
                    {property.transaction_type === "sale" ? "فروش" : "اجاره"}
                  </Badge>
                  {property.featured && <Badge className="bg-blue-600">ویژه</Badge>}
                </div>
              </div>
              <div className="text-left">
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {formatPrice(property.price, property.transaction_type)}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsFavorite(!isFavorite)}
                    className={isFavorite ? "text-red-500 border-red-500" : ""}
                  >
                    <Heart className={`h-4 w-4 ml-1 ${isFavorite ? "fill-current" : ""}`} />
                    {isFavorite ? "حذف از علاقه‌مندی‌ها" : "افزودن به علاقه‌مندی‌ها"}
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="h-4 w-4 ml-1" />
                    اشتراک‌گذاری
                  </Button>
                </div>
              </div>
            </div>

            {/* Quick stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="flex items-center gap-2 text-slate-600">
                <Square className="h-5 w-5" />
                <span>{property.area} متر مربع</span>
              </div>
              {property.bedrooms && (
                <div className="flex items-center gap-2 text-slate-600">
                  <Bed className="h-5 w-5" />
                  <span>{property.bedrooms} خواب</span>
                </div>
              )}
              {property.bathrooms && (
                <div className="flex items-center gap-2 text-slate-600">
                  <Bath className="h-5 w-5" />
                  <span>{property.bathrooms} سرویس</span>
                </div>
              )}
              {property.parking_spaces && (
                <div className="flex items-center gap-2 text-slate-600">
                  <Car className="h-5 w-5" />
                  <span>{property.parking_spaces} پارکینگ</span>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Description */}
              <Card>
                <CardHeader>
                  <CardTitle>توضیحات ملک</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 leading-relaxed">{property.description}</p>
                </CardContent>
              </Card>

              {/* Property details */}
              <Card>
                <CardHeader>
                  <CardTitle>مشخصات کلی</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-slate-600">نوع ملک:</span>
                        <span className="font-medium">{getPropertyTypeLabel(property.property_type)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">متراژ:</span>
                        <span className="font-medium">{property.area} متر مربع</span>
                      </div>
                      {property.bedrooms && (
                        <div className="flex justify-between">
                          <span className="text-slate-600">تعداد خواب:</span>
                          <span className="font-medium">{property.bedrooms}</span>
                        </div>
                      )}
                      {property.bathrooms && (
                        <div className="flex justify-between">
                          <span className="text-slate-600">تعداد سرویس:</span>
                          <span className="font-medium">{property.bathrooms}</span>
                        </div>
                      )}
                    </div>
                    <div className="space-y-4">
                      {property.parking_spaces && (
                        <div className="flex justify-between">
                          <span className="text-slate-600">پارکینگ:</span>
                          <span className="font-medium">{property.parking_spaces}</span>
                        </div>
                      )}
                      {property.floor_number && (
                        <div className="flex justify-between">
                          <span className="text-slate-600">طبقه:</span>
                          <span className="font-medium">{property.floor_number}</span>
                        </div>
                      )}
                      {property.total_floors && (
                        <div className="flex justify-between">
                          <span className="text-slate-600">کل طبقات:</span>
                          <span className="font-medium">{property.total_floors}</span>
                        </div>
                      )}
                      {property.year_built && (
                        <div className="flex justify-between">
                          <span className="text-slate-600">سال ساخت:</span>
                          <span className="font-medium">{property.year_built}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Features */}
              {property.features && property.features.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>امکانات</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {property.features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                          <span className="text-slate-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact card */}
              <Card>
                <CardHeader>
                  <CardTitle>تماس با مشاور</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <span className="text-blue-600 font-bold text-xl">ر</span>
                    </div>
                    <h3 className="font-bold text-lg">مشاور املاک رجایی</h3>
                    <p className="text-slate-600 text-sm">مشاور تخصصی املاک</p>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-600">حسام رجایی:</span>
                      <span className="font-medium">09141234567</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">عباس رجایی:</span>
                      <span className="font-medium">09149876543</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700">تماس تلفنی</Button>
                    <Button variant="outline" className="w-full bg-transparent">
                      ارسال پیام
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Property stats */}
              <Card>
                <CardHeader>
                  <CardTitle>آمار ملک</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Eye className="h-4 w-4 text-slate-600" />
                      <span className="text-slate-600">بازدید:</span>
                    </div>
                    <span className="font-medium">245 بار</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-slate-600" />
                      <span className="text-slate-600">تاریخ انتشار:</span>
                    </div>
                    <span className="font-medium">{new Date(property.created_at).toLocaleDateString("fa-IR")}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
