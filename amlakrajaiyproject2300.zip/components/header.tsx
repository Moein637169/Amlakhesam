"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Phone, Mail } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-sm border-b">
      {/* Top bar with contact info */}
      <div className="bg-slate-900 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>09141234567 - حسام</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>Amlakerajaei127@gmail.com</span>
              </div>
            </div>
            <div className="hidden md:block">
              <span>اردبیل، کوثر، بلوک 7، واحد 127</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="bg-blue-600 text-white p-2 rounded-lg">
              <span className="font-bold text-xl">ر</span>
            </div>
            <div>
              <h1 className="font-bold text-xl text-slate-900">مشاور املاک رجایی</h1>
              <p className="text-sm text-slate-600">خدمات تخصصی املاک</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-slate-700 hover:text-blue-600 font-medium">
              خانه
            </Link>
            <Link href="/properties" className="text-slate-700 hover:text-blue-600 font-medium">
              املاک
            </Link>
            <Link href="/about" className="text-slate-700 hover:text-blue-600 font-medium">
              درباره ما
            </Link>
            <Link href="/blog" className="text-slate-700 hover:text-blue-600 font-medium">
              وبلاگ
            </Link>
            <Link href="/contact" className="text-slate-700 hover:text-blue-600 font-medium">
              تماس با ما
            </Link>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Button className="bg-blue-600 hover:bg-blue-700">مشاوره رایگان</Button>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t pt-4">
            <div className="flex flex-col gap-4">
              <Link href="/" className="text-slate-700 hover:text-blue-600 font-medium">
                خانه
              </Link>
              <Link href="/properties" className="text-slate-700 hover:text-blue-600 font-medium">
                املاک
              </Link>
              <Link href="/about" className="text-slate-700 hover:text-blue-600 font-medium">
                درباره ما
              </Link>
              <Link href="/blog" className="text-slate-700 hover:text-blue-600 font-medium">
                وبلاگ
              </Link>
              <Link href="/contact" className="text-slate-700 hover:text-blue-600 font-medium">
                تماس با ما
              </Link>
              <Button className="bg-blue-600 hover:bg-blue-700 w-full">مشاوره رایگان</Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
