import { Suspense } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { PropertyFilters } from "@/components/property-filters"
import { PropertyGrid } from "@/components/property-grid"
import { PropertySearch } from "@/components/property-search"

export default function PropertiesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Page header */}
        <section className="bg-slate-900 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">تمام املاک</h1>
              <p className="text-xl text-slate-300">جستجو در میان بیش از 500 ملک در بهترین مناطق اردبیل</p>
            </div>
          </div>
        </section>

        {/* Search section */}
        <PropertySearch />

        {/* Properties listing */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col lg:flex-row gap-8">
                {/* Filters sidebar */}
                <div className="lg:w-1/4">
                  <Suspense fallback={<div>Loading filters...</div>}>
                    <PropertyFilters />
                  </Suspense>
                </div>

                {/* Properties grid */}
                <div className="lg:w-3/4">
                  <Suspense fallback={<div>Loading properties...</div>}>
                    <PropertyGrid />
                  </Suspense>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
