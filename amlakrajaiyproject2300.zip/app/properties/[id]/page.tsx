import { Suspense } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { PropertyDetails } from "@/components/property-details"
import { PropertyGallery } from "@/components/property-gallery"
import { PropertyContact } from "@/components/property-contact"
import { SimilarProperties } from "@/components/similar-properties"

interface PropertyPageProps {
  params: Promise<{ id: string }>
}

export default async function PropertyPage({ params }: PropertyPageProps) {
  const { id } = await params

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Suspense fallback={<div>Loading property...</div>}>
          <PropertyGallery propertyId={id} />
          <PropertyDetails propertyId={id} />
          <PropertyContact propertyId={id} />
          <SimilarProperties propertyId={id} />
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}
