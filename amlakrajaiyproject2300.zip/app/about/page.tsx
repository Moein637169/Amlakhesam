import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Award, Users, Clock, TrendingUp, Target, Heart, Shield, Star } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Page header */}
        <section className="bg-slate-900 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">درباره ما</h1>
              <p className="text-xl text-slate-300">بیش از 10 سال تجربه در خدمات تخصصی املاک اردبیل</p>
            </div>
          </div>
        </section>

        {/* Company introduction */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">مشاور املاک رجایی</h2>
                  <p className="text-lg text-slate-600 mb-6 text-pretty">
                    مشاور املاک رجایی با بیش از 10 سال تجربه در زمینه املاک، یکی از معتبرترین مشاوران املاک در شهر
                    اردبیل محسوب می‌شود. ما با تیمی از کارشناسان مجرب و متخصص، خدمات کاملی در زمینه خرید، فروش و اجاره
                    انواع املاک ارائه می‌دهیم.
                  </p>
                  <p className="text-slate-600 mb-8 text-pretty">
                    هدف ما ارائه بهترین خدمات با کیفیت بالا و قیمت‌های مناسب است. تیم ما همواره در تلاش است تا بهترین
                    گزینه‌ها را برای مشتریان عزیز فراهم کند و با صداقت و شفافیت کامل، اعتماد شما را جلب کند.
                  </p>

                  <div className="grid grid-cols-2 gap-6 mb-8">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
                      <div className="text-slate-600">معامله موفق</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600 mb-2">1000+</div>
                      <div className="text-slate-600">مشتری راضی</div>
                    </div>
                  </div>

                  <Button className="bg-blue-600 hover:bg-blue-700">تماس با ما</Button>
                </div>

                <div className="relative">
                  <img
                    src="/placeholder.svg?height=500&width=600&text=دفتر+املاک+رجایی"
                    alt="دفتر املاک رجایی"
                    className="w-full h-96 object-cover rounded-lg shadow-lg"
                  />
                  <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-lg shadow-lg">
                    <div className="text-2xl font-bold">10+</div>
                    <div className="text-sm">سال تجربه</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values section */}
        <section className="py-16 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">ارزش‌های ما</h2>
                <p className="text-lg text-slate-600">اصول و ارزش‌هایی که ما را در مسیر خدمت‌رسانی هدایت می‌کند</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Heart className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-4">صداقت</h3>
                    <p className="text-slate-600">ما همواره با صداقت و شفافیت کامل با مشتریان خود رفتار می‌کنیم</p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Shield className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-4">اعتماد</h3>
                    <p className="text-slate-600">اعتماد شما برای ما بسیار ارزشمند است و آن را حفظ می‌کنیم</p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Star className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-4">کیفیت</h3>
                    <p className="text-slate-600">ارائه خدمات با بالاترین کیفیت و استانداردهای حرفه‌ای</p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Target className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-4">تعهد</h3>
                    <p className="text-slate-600">متعهد به ارائه بهترین خدمات و رسیدن به اهداف مشتریان</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Team section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">تیم ما</h2>
                <p className="text-lg text-slate-600">کارشناسان مجرب و متخصص در خدمت شما</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <span className="text-blue-600 font-bold text-2xl">ح</span>
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-2">حسام رجایی</h3>
                    <p className="text-blue-600 mb-4">مدیر عامل و مشاور ارشد</p>
                    <p className="text-slate-600 mb-4">بیش از 10 سال تجربه در زمینه املاک</p>
                    <p className="text-slate-700 font-medium">09141234567</p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <span className="text-blue-600 font-bold text-2xl">ع</span>
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-2">عباس رجایی</h3>
                    <p className="text-blue-600 mb-4">مشاور املاک</p>
                    <p className="text-slate-600 mb-4">متخصص در املاک مسکونی و تجاری</p>
                    <p className="text-slate-700 font-medium">09149876543</p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardContent className="p-8">
                    <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <span className="text-blue-600 font-bold text-2xl">ح</span>
                    </div>
                    <h3 className="font-bold text-xl text-slate-900 mb-2">حمید رجایی</h3>
                    <p className="text-blue-600 mb-4">مشاور املاک</p>
                    <p className="text-slate-600 mb-4">کارشناس ارزیابی و قیمت‌گذاری املاک</p>
                    <p className="text-slate-700 font-medium">09145555555</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Features section */}
        <section className="py-16 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">چرا ما را انتخاب کنید؟</h2>
                <p className="text-lg text-slate-600">مزایای همکاری با مشاور املاک رجایی</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card>
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <Award className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-slate-900 mb-2">تجربه و تخصص</h3>
                        <p className="text-slate-600">
                          بیش از 10 سال تجربه در بازار املاک اردبیل و شناخت کامل از قیمت‌ها و روند بازار
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-slate-900 mb-2">تیم حرفه‌ای</h3>
                        <p className="text-slate-600">
                          کارشناسان مجرب و متخصص که همواره در خدمت شما هستند و بهترین مشاوره را ارائه می‌دهند
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <Clock className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-slate-900 mb-2">خدمات 24 ساعته</h3>
                        <p className="text-slate-600">
                          پاسخگویی و مشاوره در تمام ساعات شبانه روز برای راحتی و رفاه حال مشتریان عزیز
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <TrendingUp className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-slate-900 mb-2">بهترین قیمت‌ها</h3>
                        <p className="text-slate-600">
                          ارائه بهترین قیمت‌ها مطابق با نرخ روز بازار و تضمین بهترین معامله برای شما
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* CTA section */}
        <section className="py-16 bg-blue-600 text-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">آماده همکاری با شما هستیم</h2>
              <p className="text-xl text-blue-100 mb-8">
                برای مشاوره رایگان و کسب اطلاعات بیشتر درباره خدمات ما، همین حالا با ما تماس بگیرید
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-slate-100">
                  تماس با ما
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
                >
                  مشاهده املاک
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
