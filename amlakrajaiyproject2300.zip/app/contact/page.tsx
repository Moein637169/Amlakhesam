"use client"

import type React from "react"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Phone, Mail, MapPin, Clock, MessageCircle, Send } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
    inquiryType: "general",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const supabase = createClient()
      const { error } = await supabase.from("inquiries").insert({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        message: `${formData.subject}\n\n${formData.message}`,
        inquiry_type: formData.inquiryType,
      })

      if (error) throw error

      setSubmitted(true)
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
        inquiryType: "general",
      })
    } catch (error) {
      console.error("Error submitting contact form:", error)
      alert("خطا در ارسال پیام. لطفاً دوباره تلاش کنید.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Page header */}
        <section className="bg-slate-900 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">تماس با ما</h1>
              <p className="text-xl text-slate-300">
                برای مشاوره رایگان و کسب اطلاعات بیشتر درباره خدمات ما، با ما در تماس باشید
              </p>
            </div>
          </div>
        </section>

        {/* Contact form and info */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              {submitted ? (
                <Card className="max-w-2xl mx-auto">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageCircle className="h-8 w-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">پیام شما ارسال شد</h3>
                    <p className="text-slate-600 mb-6">
                      پیام شما با موفقیت ارسال شد. کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت.
                    </p>
                    <Button onClick={() => setSubmitted(false)} variant="outline">
                      ارسال پیام جدید
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  {/* Contact form */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-2xl">فرم تماس</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-2">
                              نام و نام خانوادگی *
                            </label>
                            <Input
                              value={formData.name}
                              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                              placeholder="نام خود را وارد کنید"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-slate-700 mb-2">شماره تماس *</label>
                            <Input
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              placeholder="09xxxxxxxxx"
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">ایمیل</label>
                          <Input
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            placeholder="example@email.com"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">نوع درخواست</label>
                          <Select
                            value={formData.inquiryType}
                            onValueChange={(value) => setFormData({ ...formData, inquiryType: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="general">سوال عمومی</SelectItem>
                              <SelectItem value="info">درخواست اطلاعات</SelectItem>
                              <SelectItem value="viewing">درخواست بازدید</SelectItem>
                              <SelectItem value="offer">پیشنهاد همکاری</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">موضوع</label>
                          <Input
                            value={formData.subject}
                            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                            placeholder="موضوع پیام خود را وارد کنید"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">پیام *</label>
                          <Textarea
                            value={formData.message}
                            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                            placeholder="پیام خود را بنویسید..."
                            rows={5}
                            required
                          />
                        </div>

                        <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
                          <Send className="h-4 w-4 ml-2" />
                          {isSubmitting ? "در حال ارسال..." : "ارسال پیام"}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>

                  {/* Contact information */}
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-2xl">اطلاعات تماس</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="text-center mb-6">
                          <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <span className="text-blue-600 font-bold text-2xl">ر</span>
                          </div>
                          <h3 className="font-bold text-xl text-slate-900">مشاور املاک رجایی</h3>
                          <p className="text-slate-600">مشاور تخصصی املاک اردبیل</p>
                        </div>

                        <div className="space-y-4">
                          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg">
                            <Phone className="h-6 w-6 text-blue-600 mt-1" />
                            <div>
                              <h4 className="font-medium text-slate-900 mb-2">شماره‌های تماس</h4>
                              <div className="space-y-1 text-slate-600">
                                <p>حسام رجایی: 09141234567</p>
                                <p>عباس رجایی: 09149876543</p>
                                <p>حمید رجایی: 09145555555</p>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg">
                            <Mail className="h-6 w-6 text-blue-600 mt-1" />
                            <div>
                              <h4 className="font-medium text-slate-900 mb-2">ایمیل</h4>
                              <p className="text-slate-600">Amlakerajaei127@gmail.com</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg">
                            <MapPin className="h-6 w-6 text-blue-600 mt-1" />
                            <div>
                              <h4 className="font-medium text-slate-900 mb-2">آدرس دفتر</h4>
                              <p className="text-slate-600">اردبیل، کوثر، بلوک 7، واحد 127</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg">
                            <Clock className="h-6 w-6 text-blue-600 mt-1" />
                            <div>
                              <h4 className="font-medium text-slate-900 mb-2">ساعات کاری</h4>
                              <div className="space-y-1 text-slate-600">
                                <p>شنبه تا چهارشنبه: 8:00 - 20:00</p>
                                <p>پنج‌شنبه: 8:00 - 18:00</p>
                                <p>جمعه: تعطیل</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <Button className="bg-green-600 hover:bg-green-700">
                            <Phone className="h-4 w-4 ml-1" />
                            تماس تلفنی
                          </Button>
                          <Button variant="outline">
                            <MessageCircle className="h-4 w-4 ml-1" />
                            پیام واتساپ
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Map placeholder */}
                    <Card>
                      <CardHeader>
                        <CardTitle>موقعیت دفتر</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-slate-200 h-64 rounded-lg flex items-center justify-center">
                          <div className="text-center text-slate-500">
                            <MapPin className="h-12 w-12 mx-auto mb-2" />
                            <p>نقشه موقعیت دفتر</p>
                            <p className="text-sm">اردبیل، کوثر، بلوک 7</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">سوالات متداول</h2>
                <p className="text-lg text-slate-600">پاسخ سوالات رایج درباره خدمات ما</p>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-lg text-slate-900 mb-2">آیا مشاوره شما رایگان است؟</h3>
                    <p className="text-slate-600">
                      بله، مشاوره اولیه ما کاملاً رایگان است. شما می‌توانید بدون هیچ هزینه‌ای با کارشناسان ما مشورت کنید.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-lg text-slate-900 mb-2">چه مناطقی را پوشش می‌دهید؟</h3>
                    <p className="text-slate-600">
                      ما تمام مناطق شهر اردبیل از جمله کوثر، مرکز شهر، شهرک صنعتی و حومه شهر را پوشش می‌دهیم.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-lg text-slate-900 mb-2">چقدر طول می‌کشد تا ملک من فروخته شود؟</h3>
                    <p className="text-slate-600">
                      زمان فروش ملک بستگی به عوامل مختلفی دارد، اما معمولاً بین 1 تا 3 ماه طول می‌کشد. ما تلاش می‌کنیم تا
                      در کمترین زمان ممکن ملک شما را بفروشیم.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-lg text-slate-900 mb-2">آیا خدمات ارزیابی ملک ارائه می‌دهید؟</h3>
                    <p className="text-slate-600">
                      بله، ما خدمات ارزیابی تخصصی ملک با قیمت روز بازار ارائه می‌دهیم. این خدمت برای مشتریان ما رایگان
                      است.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
