import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, User, ArrowLeft } from "lucide-react"
import Link from "next/link"

// Sample blog posts data
const blogPosts = [
  {
    id: "1",
    title: "راهنمای کامل خرید آپارتمان در اردبیل",
    excerpt: "نکات مهم و ضروری که باید قبل از خرید آپارتمان در اردبیل بدانید",
    content: "محتوای کامل مقاله...",
    image: "/placeholder.svg?height=300&width=400&text=راهنمای+خرید+آپارتمان",
    author: "حسام رجایی",
    date: "1403/09/15",
    tags: ["خرید آپارتمان", "راهنما", "اردبیل"],
    readTime: "5 دقیقه",
  },
  {
    id: "2",
    title: "بهترین مناطق برای سرمایه‌گذاری املاک در اردبیل",
    excerpt: "بررسی مناطق پرطرفدار و پرسود برای سرمایه‌گذاری در بازار املاک اردبیل",
    content: "محتوای کامل مقاله...",
    image: "/placeholder.svg?height=300&width=400&text=سرمایه‌گذاری+املاک",
    author: "عباس رجایی",
    date: "1403/09/10",
    tags: ["سرمایه‌گذاری", "املاک", "اردبیل"],
    readTime: "7 دقیقه",
  },
  {
    id: "3",
    title: "نکات مهم در اجاره دادن ملک",
    excerpt: "چگونه ملک خود را با بهترین قیمت و به مستأجر مناسب اجاره دهیم",
    content: "محتوای کامل مقاله...",
    image: "/placeholder.svg?height=300&width=400&text=اجاره+ملک",
    author: "حمید رجایی",
    date: "1403/09/05",
    tags: ["اجاره", "مالک", "نکات"],
    readTime: "4 دقیقه",
  },
]

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Page header */}
        <section className="bg-slate-900 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">وبلاگ املاک</h1>
              <p className="text-xl text-slate-300">آخرین اخبار، راهنماها و نکات مفید در زمینه املاک</p>
            </div>
          </div>
        </section>

        {/* Blog posts */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts.map((post) => (
                  <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <img
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-3 right-3">
                        <Badge className="bg-blue-600">{post.readTime}</Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 text-sm text-slate-500 mb-3">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>{post.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          <span>{post.author}</span>
                        </div>
                      </div>

                      <h3 className="font-bold text-lg text-slate-900 mb-3 line-clamp-2">{post.title}</h3>
                      <p className="text-slate-600 mb-4 line-clamp-3">{post.excerpt}</p>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {post.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <Link href={`/blog/${post.id}`}>
                        <Button variant="outline" className="w-full bg-transparent">
                          ادامه مطلب
                          <ArrowLeft className="h-4 w-4 mr-2" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Load more */}
              <div className="text-center mt-12">
                <Button variant="outline" size="lg">
                  نمایش مطالب بیشتر
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Newsletter signup */}
        <section className="py-16 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">عضویت در خبرنامه</h2>
              <p className="text-lg text-slate-600 mb-8">
                برای دریافت آخرین اخبار و مطالب املاک، در خبرنامه ما عضو شوید
              </p>
              <div className="flex gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="ایمیل خود را وارد کنید"
                  className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <Button className="bg-blue-600 hover:bg-blue-700">عضویت</Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
