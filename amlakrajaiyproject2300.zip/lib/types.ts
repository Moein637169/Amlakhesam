export interface Property {
  id: string
  title: string
  description: string
  price: number
  area: number
  bedrooms?: number
  bathrooms?: number
  parking_spaces?: number
  property_type: "apartment" | "house" | "villa" | "commercial" | "land"
  transaction_type: "sale" | "rent"
  status: "available" | "sold" | "rented" | "pending"
  address: string
  neighborhood?: string
  floor_number?: number
  total_floors?: number
  year_built?: number
  features?: string[]
  images?: string[]
  video_url?: string
  featured: boolean
  created_at: string
  updated_at: string
}

export interface Inquiry {
  id: string
  property_id?: string
  name: string
  email?: string
  phone: string
  message?: string
  inquiry_type: "info" | "viewing" | "offer" | "general"
  status: "new" | "contacted" | "closed"
  created_at: string
  updated_at: string
}

export interface BlogPost {
  id: string
  title: string
  content: string
  excerpt?: string
  featured_image?: string
  author: string
  published: boolean
  tags?: string[]
  created_at: string
  updated_at: string
}

export interface User {
  id: string
  email: string
  role: "admin" | "user"
  created_at: string
  updated_at: string
}
