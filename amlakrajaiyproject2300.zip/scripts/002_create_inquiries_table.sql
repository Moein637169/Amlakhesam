-- Create inquiries table for property inquiries
CREATE TABLE IF NOT EXISTS public.inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES public.properties(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  message TEXT,
  inquiry_type TEXT NOT NULL CHECK (inquiry_type IN ('viewing', 'info', 'offer', 'general')),
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'closed')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_inquiries_property ON public.inquiries(property_id);
CREATE INDEX IF NOT EXISTS idx_inquiries_status ON public.inquiries(status);
CREATE INDEX IF NOT EXISTS idx_inquiries_created_at ON public.inquiries(created_at);

-- Enable Row Level Security
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

-- Public can insert inquiries
CREATE POLICY "inquiries_insert_public" 
  ON public.inquiries FOR INSERT 
  WITH CHECK (true);

-- Only authenticated users (admin) can view/update inquiries
CREATE POLICY "inquiries_select_admin" 
  ON public.inquiries FOR SELECT 
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "inquiries_update_admin" 
  ON public.inquiries FOR UPDATE 
  USING (auth.uid() IS NOT NULL);
