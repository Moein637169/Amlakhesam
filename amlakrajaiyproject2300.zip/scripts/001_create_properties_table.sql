-- Create properties table for real estate listings
CREATE TABLE IF NOT EXISTS public.properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  price DECIMAL(15,2) NOT NULL,
  property_type TEXT NOT NULL CHECK (property_type IN ('apartment', 'house', 'villa', 'commercial', 'land')),
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('sale', 'rent')),
  area DECIMAL(10,2) NOT NULL, -- in square meters
  bedrooms INTEGER,
  bathrooms INTEGER,
  parking_spaces INTEGER DEFAULT 0,
  floor_number INTEGER,
  total_floors INTEGER,
  year_built INTEGER,
  address TEXT NOT NULL,
  city TEXT NOT NULL DEFAULT 'اردبیل',
  neighborhood TEXT,
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  features TEXT[], -- array of features like 'elevator', 'balcony', etc.
  images TEXT[], -- array of image URLs
  video_url TEXT,
  virtual_tour_url TEXT,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'sold', 'rented', 'pending')),
  featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_properties_city ON public.properties(city);
CREATE INDEX IF NOT EXISTS idx_properties_type ON public.properties(property_type);
CREATE INDEX IF NOT EXISTS idx_properties_transaction ON public.properties(transaction_type);
CREATE INDEX IF NOT EXISTS idx_properties_price ON public.properties(price);
CREATE INDEX IF NOT EXISTS idx_properties_status ON public.properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_featured ON public.properties(featured);
CREATE INDEX IF NOT EXISTS idx_properties_created_at ON public.properties(created_at);

-- Enable Row Level Security
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access (properties are public)
CREATE POLICY "properties_select_all" 
  ON public.properties FOR SELECT 
  USING (status = 'available' OR status = 'pending');

-- Admin policies (only authenticated users can insert/update/delete)
CREATE POLICY "properties_insert_admin" 
  ON public.properties FOR INSERT 
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "properties_update_admin" 
  ON public.properties FOR UPDATE 
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "properties_delete_admin" 
  ON public.properties FOR DELETE 
  USING (auth.uid() IS NOT NULL);
